package common;

import javax.swing.JPanel;

public abstract class PaneWithFuncModel {


    public abstract void setPanelFrame(JPanel mJPane);
    public abstract void setPanelFuncModel();
}
