package common;

public interface IPaneSet {

    public void setPaneLayout();

}
