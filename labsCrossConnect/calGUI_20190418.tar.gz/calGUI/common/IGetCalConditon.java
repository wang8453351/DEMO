package common;

import java.util.Map;

public interface IGetCalConditon {
    public  Map<String,String> condition = null;
}
