package common;

public interface IJMenuBar {


    public void addJMenuToJMenuBar();
    public void addJMenuItemToJMenu();
//    public void updateJMenuBar();

}
